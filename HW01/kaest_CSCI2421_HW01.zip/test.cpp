#include <iostream>

using std::cout;
using std::cin;
using std::endl;




int main(){


    return 0;
}
