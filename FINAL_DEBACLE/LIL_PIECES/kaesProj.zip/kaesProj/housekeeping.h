#include "exception.h"
exception_status readInPeople();
exception_status readInPictures();
int getSearchTerm(std::string&, std::string);
