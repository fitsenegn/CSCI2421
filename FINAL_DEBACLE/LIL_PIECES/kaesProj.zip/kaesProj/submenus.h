#ifndef interface_h_
#define interface_h_
#include <iostream>


void banner();
void optionBanner();
void importBanner();
int Actress_Actor();
int Pictures();
void duelPrint();
int options();
int importExport();
void test();

#endif
